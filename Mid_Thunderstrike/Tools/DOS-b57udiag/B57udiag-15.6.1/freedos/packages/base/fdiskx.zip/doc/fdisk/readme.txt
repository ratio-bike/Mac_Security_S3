README.TXT

Readme File:

Program:  FDISK.EXE

Version:  1.2.0

Author:  Brian E. Reifsnyder
	 reifsnyderb@mindspring.com

Note:  For a list of files included in the zip file with Free FDISK please
       read the file filelist.txt.


Description:  Partition management utility.

Compiler:  Borland Turbo C++ 3.0 (Program is written in C)

Licensing:  Licensed under the GNU GPL.

Warranties:  This program does not have any warranties, either stated or
	     implied.  By using this program, you are assuming full
	     responsibility for the outcome of the program's execution.

Operating systems this program is known to work under:
	 MS-DOS 6.22
         MS-Windows 95 (Single-tasking DOS mode only.)
	 MS-Windows 98 2nd Edition (No problems.)
         FreeDOS

Operating systems this program will not work under:
	 MS-Windows NT 4.0 (No major loss :-)  ) (This is due to NT's control over 
	   direct access to hardware.)
         MS-Windows 2000
         Linux

Misc. Notes:

Future Plans:
(These may be changed at any time.)

        See news.txt

Note:  Please read the file bloader.txt if you need brief instructions for 
       the bootloader and for licensing information.


