#Translated by Mateusz Viste "Fox" / the.killer@wp.pl
#Polish diacritics encoded with the MAZOVIA standard
#
0.0:Oczekuje na naci�ni�cie jakiego� klawisza z listy wybor�w
0.1:wybory
0.2:tekst
0.3:Okre�la dost�pne klawisze.  Domy�lne to:
0.4:Nie wy�wietla mo�liwych wybor�w po pytaniu
0.5:Rozr��nia ma�e i wielkie litery
0.6:Automatycznie wybiera klawisz c po nn sekundach
0.7:Tekst wy�wietlany jako pytanie
0.8:Odtwarza BEEP po pytaniu
3.0:tn

0.9:Niepoprawna sk�adnia czasu. Oczekiwana forma to Tc,nn lub T:c,nn
0.10:Automatycznie wybierany klawisz nie znajduje si� na li�cie dost�pnych
