#Translated by Mateusz Viste "Fox" / the.killer@wp.pl
#Polish letters encoded in the MAZOVIA standard
#Homepage: http://www.the.killer.webpark.pl/en/fdos_pl.htm
#
0.0:Wy�wietla temat pomocy
0.1:U�ycie:
0.2:temat
0.3:�rodowisko:
0.4:Program wy�wietlaj�cy plik tekstowy
0.5:Katalog zawieraj�cy pliki pomocy
0.6:Preferowany j�zyk dla plik�w pomocy
1.0:Nie mo�na uruchomi� programu wy�wietlaj�cego.
